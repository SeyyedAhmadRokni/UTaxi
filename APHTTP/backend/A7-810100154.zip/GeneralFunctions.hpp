#ifndef _GE_H
#define _GE_H
#include <bits/stdc++.h>

std::vector<std::string> split (std::string input, char seprator);
bool stringToBool(std::string input);

#endif