#ifndef _LOC_H
#define _LOC_H

class Location{
private:
    double latitude, longitude;

public:
    Location(double latitude, double logitude);
    double getLatitude();
    double getLongitude();
};

#endif